#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "LED.h"
#include "Key.h"
#include "OLED.h"

uint8_t Count;

int main(void)
{
	OLED_Init();
	LED_Init();
	Key_Init();
	OLED_ShowString(1,1,"Count:");
	while(1)
	{
		
	}
}

void EXTI1_IRQHandler(void)
{
	Delay_ms(10);                                         //延时，更加稳定
	if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) == 0)     //重复判断，更稳定
	{
		LED1_Turn();
		Count++;                                          //记录中断次数
		OLED_ShowNum(1,7,Count,3);
	}
	EXTI_ClearITPendingBit(EXTI_Line1);
}	
