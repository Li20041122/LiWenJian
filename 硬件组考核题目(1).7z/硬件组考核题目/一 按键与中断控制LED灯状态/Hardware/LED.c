#include "stm32f10x.h"                  // Device header

void LED_Init(void)
{
	//开启时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);         //开启AFIO的时钟
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode= GPIO_Mode_Out_PP;              //推挽输出
	GPIO_InitStructure.GPIO_Pin= GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	//因为是低电平点亮，所以设置默认电平为高电平
	GPIO_SetBits(GPIOA,GPIO_Pin_1 | GPIO_Pin_2);
	
	//EXIT中断                                                   //此处要开启AFIO才管用
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource1);   //选择用作外部中断线源的GPIO端口
	
	EXTI_InitTypeDef EXTI_InitStructure;
	EXTI_InitStructure.EXTI_Line = EXTI_Line1;                   //选择中断行
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;                    //使能
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;          //选择中断模式
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;      //选择下降沿为触发模式
	EXTI_Init(&EXTI_InitStructure);                              //EXTI配置初始化
	
	//配置NVIC
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);              //优先级分组
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;             //选择中断通道
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;              //使能
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;    //抢占优先级 
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;           //响应优先级
	NVIC_Init(&NVIC_InitStructure);
}

//LED1电平翻转
void LED1_Turn()
{
	if(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_1)==0)
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_1);
	}
	else
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_1);
	}
}


