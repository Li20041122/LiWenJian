#include "stm32f10x.h"                  // Device header

//初始化函数
void MyCAN_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);   //开启can的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  //开启GPIOA的时钟
	
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;        //模式为复用推挽输出
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;             //GPIOA_12号引脚
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;      
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;          //模式为上拉输入
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;             //GPIOA_11号引脚
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	//CAN初始化
	CAN_InitTypeDef CAN_InitStructure;
	//波特率:125000bps
	CAN_InitStructure.CAN_Prescaler = 48;                  //设置1tq的大小
	CAN_InitStructure.CAN_Mode = CAN_Mode_Normal;          //设置为正常模式
	CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;               //设置补偿宽度值大小
	CAN_InitStructure.CAN_BS1 = CAN_BS1_2tq;               //设置相位缓冲段1大小
	CAN_InitStructure.CAN_BS2 = CAN_BS2_3tq;               //设置相位缓冲段2大小
	CAN_InitStructure.CAN_TTCM = DISABLE;                  //禁止时间触发通信模式(不用内部定时器)
	CAN_InitStructure.CAN_ABOM = DISABLE;				   //禁止自动离线管理模式
	CAN_InitStructure.CAN_AWUM = DISABLE;                  //禁止自动唤醒模式
	CAN_InitStructure.CAN_NART = DISABLE;             	   //启用报文自动重传
	CAN_InitStructure.CAN_RFLM = DISABLE;                  //接收FIFO锁定模式(这里选择的是覆盖式)		
	CAN_InitStructure.CAN_TXFP = DISABLE;                  //发送FIFO优先级(优先级由报文的标识符)
	CAN_Init(CAN1, &CAN_InitStructure);                    //初始化can
	
	
	
	//can过滤器初始化
	CAN_FilterInitTypeDef CAN_FilterInitStructure;
	//FilterID为过滤的地址，FilterMask与FilterID对应每一位表示是否需要匹配当前位。
	CAN_FilterInitStructure.CAN_FilterIdHigh = 0x0000;
	CAN_FilterInitStructure.CAN_FilterIdLow = 0x0000;
	//mask设置为全1，表示所有为必须匹配，也就是只接受和FilterID一样的数据
	//mask设置为全0，就是任何一位都不需要匹配；
	//注意如果要mask不是全0时，要对应好位置匹配ID，这里是32位
	CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0x0000;                       //设置标识符寄存器高位
	CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0x0000;                        //设置标识符寄存器低位
	CAN_FilterInitStructure.CAN_FilterFIFOAssignment = CAN_Filter_FIFO0;         //过滤之后要储存在哪个FIFO
	
	CAN_FilterInitStructure.CAN_FilterNumber = 0;                                //指定待初始化的过滤器为0     
	CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask;              //模式为标识符屏蔽位模式(某些值相同就可以了)
	CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;             //一个32位过滤器
	CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;                       //使能过滤器
	CAN_FilterInit(&CAN_FilterInitStructure);
}

//发送信息
void MyCAN_Transmit(uint32_t ID, uint8_t Length, uint8_t *Data)
{
	CanTxMsg TxMessage;
	TxMessage.StdId = ID;                       //设定标准标识符
	TxMessage.ExtId = ID;                       //设定扩展标识符
	TxMessage.IDE = CAN_Id_Standard;            //使用标准标识符  
	TxMessage.RTR = CAN_RTR_Data;               //数据帧
	TxMessage.DLC = Length;                     //发送字节个数
	for (uint8_t i = 0; i < Length; i ++)
	{
		TxMessage.Data[i] = Data[i];            //存入数据
	}
	//如果没有空闲的传输邮箱可用，CAN_Transmit()则返回CAN_TxStatus_NoMailBox;有空邮箱就把消息存储到空邮箱里
	uint8_t TransmitMailbox = CAN_Transmit(CAN1, &TxMessage);              //返回值是一个空邮箱的号码
	while (CAN_TransmitStatus(CAN1, TransmitMailbox) != CAN_TxStatus_Ok);  //检查消息传输的状态
}

//接收标志位
uint8_t MyCAN_ReceiveFlag(void)
{
	if (CAN_MessagePending(CAN1, CAN_FIFO0) > 0)                           //获取当前接收FIFO中挂号的报文个数
	{
		return 1;
	}
	return 0;
}

//接收信息
void MyCAN_Receive(uint32_t *ID, uint8_t *Length, uint8_t *Data)
{
	CanRxMsg RxMessage;
	
	CAN_Receive(CAN1, CAN_FIFO0, &RxMessage);             //检测邮箱中是否有数据，有则取出来放在结构体中
	
	if (RxMessage.IDE == CAN_Id_Standard)                 //检查数据是否是标准标识符
	{
		*ID = RxMessage.StdId;
	}
	if (RxMessage.RTR == CAN_RTR_Data)                    //检查数据是否是数据帧
	{
		*Length = RxMessage.DLC;                          //取出字节个数
		for (uint8_t i = 0; i < *Length; i ++)          
		{
			Data[i] = RxMessage.Data[i];                  //放在数组中
		}
	}
}
