#include "stm32f10x.h"                  // Device header
#include "String.h"
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "Key.h"
#include "LED.h"

uint8_t RXData;
uint8_t KeyNum;

int main(void)
{
	LED_Init();
	Key_Init();
	OLED_Init();
	Serial_Init();
	OLED_ShowString(1,1,"TxPackage:");
	OLED_ShowString(3,1,"RxPackage:");
	
	while(1)
	{
		if(GetFlag() == 1)                                      //标志位置1说明有文本数据包
		{
			OLED_ShowString(4,1,"                ");            //清空一行，保证不受上一次的影响
			OLED_ShowString(4,1,RX_DataPackage);
			if(strcmp(RX_DataPackage,"LED1_On") == 0)           //对比，开启LED
			{
				LED1_On();
				Send_String("LED1_On_Ok\r\n");
				OLED_ShowString(2,1,"                ");         //清空一行，防止覆盖
				OLED_ShowString(2,1,"LED1_On_Ok");
			}
			else if(strcmp(RX_DataPackage,"LED1_Off")==0)        //关闭LED
			{
				LED1_Off();
				Send_String("LED1_Off_Ok\r\n");
				OLED_ShowString(2,1,"                ");
				OLED_ShowString(2,1,"LED1_Off_Ok");
			}
			else
			{
				Send_String("Error_Command\r\n");
				OLED_ShowString(2,1,"                ");
				OLED_ShowString(2,1,"Error_Command");
			}
		}
	}
}
