#include "stm32f10x.h"                  // Device header

char RX_DataPackage[100]={0};
uint8_t RX_Flag;

void Serial_Init(void)
{
	//开启串口时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	//复用推挽输出
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	//配置另一个接收端口
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	//串口初始化
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 9600;                                        //波特率
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;   //不用硬件流控制
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;                   //接收与发送模式都选择
	USART_InitStructure.USART_Parity = USART_Parity_No;                               //不选校验位
	USART_InitStructure.USART_StopBits = USART_StopBits_1;                            //一位停止位
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;                       //数据位长度
	USART_Init(USART1,&USART_InitStructure);
	//配置中断
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);                 //使能接收中断
	//配置NVIC
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);              //优先级分组
	NVIC_InitTypeDef NVIC_InitStructure; 
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;       	 //要启用的通道
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStructure);
	//开启串口
	USART_Cmd(USART1,ENABLE);                                    //使能
}

//接受数据
uint16_t Receive_Byte(void)                                     
{
	if(USART_GetFlagStatus(USART1,USART_FLAG_RXNE) == SET)       //如果接收寄存器非空
	{
		return USART_ReceiveData(USART1);                        //收到的数据
	}
	else
		return 0;
}
//发送数据
void Send_Byte(uint16_t Byte)
{
	USART_SendData(USART1,Byte);
	while(USART_GetFlagStatus(USART1,USART_FLAG_TXE) == RESET);  //如果发送数据位不空，即数据还没转到发送移位寄存器
}

void Send_String(char *String)
{
	uint8_t i;
	for(i=0;String[i]!='\0';i++)
	{
		Send_Byte(String[i]);
	}
}

//接收标志位
uint8_t GetFlag(void)
{
	if(RX_Flag == 1)
	{
		RX_Flag = 0;
		return 1;
	}
	else
	{
		return 0;
	}
}

//中断函数
void USART1_IRQHandler(void)
{
	static uint8_t RxState = 0;
	static uint8_t Count = 0;
	if(USART_GetITStatus(USART1,USART_IT_RXNE) == SET)  //确保进入的是接收中断
	{
		uint8_t RXDATA = USART_ReceiveData(USART1);     //每次进入中断就赋值
		if(RxState == 0)                                //第一个阶段
		{
			if(RXDATA == '@')
			{
				RxState = 1;          //进入下一个阶段
				Count = 0;            //计数清零
			}
		}
		else if(RxState == 1)
		{
			if(RXDATA == '\r')                          //判断倒数第二个标志位
			{
				RxState = 2;                            //进入下一个阶段
			}
			else 
			{
				RX_DataPackage[Count++]=RXDATA;         //把接收的数据存储到字符数组中，同时计数	
			}
		}
		else if(RxState == 2)                           //第三个阶段
		{
			if(RXDATA == '\n')
			{
				RX_Flag = 1;             		//接收结束，标志位置1
				RX_DataPackage[Count]='\0';     //赋值结束条件  
				RxState = 0;            	    //重新接收下一个数据包
			}
		}
		USART_ClearITPendingBit(USART1,USART_IT_RXNE);   //清除标志位
	}
}
