#include "stm32f10x.h"                  // Device header
#include "Delay.h"
uint16_t CountSensor_Count = 0;
void CountSensor_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	//先初始化GPIOB
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	//再配置AFIO
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource14);
	//再配置Exit
	EXTI_InitTypeDef EXIT_InitStructure;
	EXIT_InitStructure.EXTI_Line = EXTI_Line14;
	EXIT_InitStructure.EXTI_LineCmd = ENABLE;
	EXIT_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXIT_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_Init(&EXIT_InitStructure);
	//再配置NVIC
	//1.先分组
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	//2.再初始化
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
}
//返回数字
uint16_t Get_CountSensor(void)
{
	return CountSensor_Count;
}
//再写中断函数
void EXTI15_10_IRQHandler(void)
{
	if((EXTI_GetFlagStatus(EXTI_Line14)) == SET)
	{
		//消抖1
		Delay_ms(20);
		//消抖2
		if((GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14)) == 0)
		CountSensor_Count++;
		EXTI_ClearFlag(EXTI_Line14);
	}
}

