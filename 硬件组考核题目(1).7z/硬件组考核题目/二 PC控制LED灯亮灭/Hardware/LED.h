#ifndef __LED_H
#define __LED_H

void LED_Init(void);
void LED_Set(uint16_t Pin,FunctionalState turn);
void LED0_Turn(void);
void LED1_Turn(void);
void LED1_On(void);
void LED1_Off(void);

#endif
