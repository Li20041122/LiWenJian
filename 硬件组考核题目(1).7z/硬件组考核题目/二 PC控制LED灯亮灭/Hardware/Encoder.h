#ifndef __ENCODER_H
#define __ENCODER_H

int16_t GetEncoderConunt(void);
void Encoder_Init(void);

#endif
