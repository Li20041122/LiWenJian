#ifndef __IC_H
#define __IC_H

void IC_Init(void);
uint32_t Get_IC_CCR(void);

#endif
