#include "stm32f10x.h"                  // Device header
#include "PWM.h"

void Servo_Init(void)
{
	PWM_Init();
}

void Set_Ankle(float Ankle)
{
	TIM_SetCompare2(TIM2,Ankle / 180 * 2000 + 500);
}

