#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"
#include "Key.h"

uint8_t KeyNum;
float Angle;

int main(void)
{
	OLED_Init();
	Servo_Init();
	Key_Init();
	OLED_ShowString(1,1,"Angle:");
	
	Servo_SetAngle(90);
	while(1)
	{
		KeyNum=Key_GetNum();               //读取按键数值
		if(KeyNum==1)
		{
			Angle+=30;                     //每次加30度
			if(Angle>180)                  //大于180度置0
			{
				Angle=0;
			}
		}
		Servo_SetAngle(Angle);
		OLED_ShowNum(1,7,Angle,3);
	}
}
