#include "stm32f10x.h"                  // Device header

void PWM_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	//初始化GPIO
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	//选复用推挽输出
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	//选择时基单元的时钟
	TIM_InternalClockConfig(TIM2);                                           //这样Tim2的时基单元就由内部单元来驱动了
	//配置时基单元
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;              //不分频
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;          //向上计数
	//PWM频率：Freq = 时钟频率 / (PSC + 1) / (ARR + 1)   
	//频率：72000000 / 20000 / 72 = 50  
	//周期：1 / 50 = 0.02s = 20ms
	TIM_TimeBaseInitStructure.TIM_Period = 20000 - 1;     					 //ARR             
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;  						 //PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;                     //重复计数器(暂时不用)
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructure);
	//初始化输出比较单元
	TIM_OCInitTypeDef TIM_OCInitStructure;
	//给结构体付初始值
	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode=TIM_OCMode_PWM1;                         //输出比较模式选为PWM1
	TIM_OCInitStructure.TIM_OCPolarity=TIM_OCPolarity_High;                 //输出比较极性,有效电平是高电平	
	TIM_OCInitStructure.TIM_OutputState=TIM_OutputState_Enable;             //输出使能 
	TIM_OCInitStructure.TIM_Pulse=0;   									    //CCR	
	TIM_OC2Init(TIM2,&TIM_OCInitStructure);
	
	TIM_Cmd(TIM2,ENABLE);                                                   //定时器使能
}
//设置CCR
void PWM_SetCompare2(uint16_t Compare)
{
	TIM_SetCompare2(TIM2,Compare);
}
