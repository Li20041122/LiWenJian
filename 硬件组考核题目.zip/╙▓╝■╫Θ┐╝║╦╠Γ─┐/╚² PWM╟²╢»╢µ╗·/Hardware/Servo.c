#include "stm32f10x.h"                  // Device header
#include "PWM.h"

void Servo_Init(void)
{
	PWM_Init();
}
//设置角度
void Servo_SetAngle(float Angle)
{
	//ARR:20000 周期:20ms   度数:
	//    500        0.5ms       0
	//    1000       1ms         45
	//    2500       2.5ms       180
	//角度比例
	PWM_SetCompare2(Angle / 180 * 2000 + 500);     //换算角度公式
}
