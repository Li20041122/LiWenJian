#include "stm32f10x.h"                  // Device header
//初始化LED
void LED_Init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	//推挽输出
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	GPIO_SetBits(GPIOA,GPIO_Pin_1);
}
/**
  * 函    数：GPIOA的LED_0或LED_1开启或关闭
  * 参    数：第一个参数是端口，第二个参数是ENABLE或DISABLE
  * 返 回 值：无
  */
void LED_Set(uint16_t Pin,FunctionalState turn)
{
	if(Pin==GPIO_Pin_0)
	{
		if(turn==ENABLE)
		{
			GPIO_ResetBits(GPIOA,Pin);
		}
		else
		{
			GPIO_SetBits(GPIOA,Pin);
		}
	}
	if(Pin==GPIO_Pin_1)
	{
		if(turn==ENABLE)
		{
			GPIO_ResetBits(GPIOA,Pin);
		}
		else
		{
			GPIO_SetBits(GPIOA,Pin);
		}
	}
}

void LED1_On(void)
{
	GPIO_ResetBits(GPIOA,GPIO_Pin_1);
}
void LED1_Off(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_1);
}
/**
  * 函    数：LED0状态翻转
  * 参    数：无
  * 返 回 值：无
  */
void LED0_Turn(void)
{
	if((GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_0)) == 1)
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_0);
	}
	else
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_0);
	}
}
/**
  * 函    数：LED1状态翻转
  * 参    数：无
  * 返 回 值：无
  */
void LED1_Turn(void)
{
	if((GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_1)) == 1)
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_1);
	}
	else
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_1);
	}
}

