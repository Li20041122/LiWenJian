#ifndef __SERVO_H
#define __SERVO_H

void Servo_Init(void);
void Set_Ankle(float Ankle);

#endif
