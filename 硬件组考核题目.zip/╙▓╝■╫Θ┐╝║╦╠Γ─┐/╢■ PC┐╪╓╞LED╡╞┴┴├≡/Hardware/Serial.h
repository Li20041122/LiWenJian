#ifndef __SERIAL_H
#define __SERIAL_H


extern char RX_DataPackage[100];

void Serial_Init(void);
void Send_Byte(uint16_t Byte);
void Send_String(char *String);
uint16_t Receive_Byte(void);
uint8_t GetFlag(void);


#endif
