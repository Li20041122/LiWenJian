#ifndef __ENCODER2_H
#define __ENCODER2_H

uint16_t Get_Encoder(void);
void Encoder2_Init(void);

#endif
