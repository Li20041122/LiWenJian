#ifndef __PWM_H
#define __PWM_H

void Motor_Init(void);
void Set_Speed(int8_t Speed);

#endif
